package com.example.uas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
